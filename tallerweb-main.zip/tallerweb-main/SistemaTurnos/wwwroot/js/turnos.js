﻿document.addEventListener('DOMContentLoaded', async () => {
    const btnAgendar = document.getElementById('btnAgendar');
    const btnAtender = document.getElementById('btnAtender');
    const listaTurnos = document.getElementById('listaTurnos');
    const turnoActual = document.getElementById('turnoActual');
    const userNameDisplay = document.getElementById('userName');
    const btnCambiarNombre = document.getElementById('btnCambiarNombre');

    const pedirNombre = () => {
        let nombre = '';
        while (!nombre || nombre.trim() === '') {
            nombre = prompt('¡Bienvenido al Sistema de Turnos!\nPor favor, ingrese su nombre:') || '';
            if (!nombre.trim()) {
                alert('Debe ingresar un nombre válido');
            }
        }
        localStorage.setItem('nombreUsuario', nombre.trim());
        userNameDisplay.textContent = nombre.trim();
        return nombre.trim();
    };

    let nombreUsuario = localStorage.getItem('nombreUsuario');
    if (!nombreUsuario) {
        nombreUsuario = pedirNombre();
    } else {
        userNameDisplay.textContent = nombreUsuario;
    }

    const connection = new signalR.HubConnectionBuilder()
        .withUrl("/turnosHub")
        .withAutomaticReconnect()
        .build();

    const iniciarConexion = async () => {
        try {
            await connection.start();
            console.log("Conectado a SignalR");
            await connection.invoke("ObtenerEstadoActual");
        } catch (err) {
            console.error("Error de conexión:", err);
            setTimeout(iniciarConexion, 5000);
        }
    };

    btnCambiarNombre.addEventListener('click', () => {
        nombreUsuario = pedirNombre();
    });

    btnAgendar.addEventListener('click', async () => {
        await connection.invoke("AgendarTurno", nombreUsuario);
    });

    await iniciarConexion();
});
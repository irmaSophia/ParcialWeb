﻿/* Estilos adicionales para mejorar la interfaz */
.card - header {
    border - radius: 10px 10px 0 0!important;
}

.btn - success {
    background - color: #28a745;
    border - color: #28a745;
}

.btn - warning {
    background - color: #ffc107;
    border - color: #ffc107;
    color: #212529;
}

.alert - dark {
    background - color: #343a40;
    color: white;
    border - radius: 8px;
}

#listaTurnos {
    max - height: 400px;
    overflow - y: auto;
}
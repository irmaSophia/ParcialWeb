﻿using Microsoft.AspNetCore.SignalR;
using SistemaTurnos.Models;

namespace SistemaTurnos.Hubs
{
    public class TurnosHub : Hub
    {
        private static Queue<Turno> _colaTurnos = new Queue<Turno>();
        private static Turno _turnoActual = null;
        private static int _contadorTurnos = 1;

        public async Task ObtenerEstadoActual()
        {
            await Clients.Caller.SendAsync("ActualizarListaTurnos", _colaTurnos.ToList());
            await Clients.Caller.SendAsync("ActualizarTurnoActual",
                _turnoActual?.ToString() ?? "No hay turnos en atención");
        }

        public async Task AgendarTurno(string nombreCliente)
        {
            var nuevoTurno = new Turno
            {
                Numero = _contadorTurnos++,
                NombreCliente = nombreCliente,
                FechaCreacion = DateTime.Now
            };

            _colaTurnos.Enqueue(nuevoTurno);
            await ActualizarClientes();
        }

        public async Task AtenderTurno()
        {
            if (_colaTurnos.Count > 0)
            {
                _turnoActual = _colaTurnos.Dequeue();
                await Clients.All.SendAsync("NotificarTurnoActual", $"Es tu turno: {_turnoActual.NombreCliente} - Turno #{_turnoActual.Numero}");
            }
            await ActualizarClientes();
        }

        private async Task ActualizarClientes()
        {
            await Clients.All.SendAsync("ActualizarListaTurnos", _colaTurnos.ToList());
            await Clients.All.SendAsync("ActualizarTurnoActual", _turnoActual?.ToString() ?? "No hay turnos en atención");
        }
    }
}

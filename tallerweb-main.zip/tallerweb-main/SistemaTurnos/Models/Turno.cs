﻿namespace SistemaTurnos.Models
{
    public class Turno
    {
        public int Numero { get; set; }
        public string? NombreCliente { get; set; }
        public DateTime FechaCreacion { get; set; }

        public override string ToString()
        {
            return $"Turno #{Numero} - {NombreCliente}";
        }
    }
}
